// NapCat 入群/退群检测 最终稳定版
const EventType = {
  NOTICE: "notice",
  // 入群事件
  GROUP_INCREASE: "group_increase",
  // 退群事件
  GROUP_DECREASE: "group_decrease"
};

// ===================== 可自定义配置（全部在这里改，无需动下面代码）=====================
const CONFIG = {
  // 入群欢迎开关
  enableWelcome: true,
  // 退群通知开关
  enableLeaveNotice: true,
  // 入群是否自动@新人
  atNewUser: true,
  // 消息发送延迟（毫秒），避免风控
  sendDelay: 1500,
  // 头像清晰度：100/640，640=高清大图
  avatarSize: 640,
  // 是否开启控制台日志
  enableLog: true,

  // ===================== 文案自定义 =====================
  // 入群欢迎文案，支持变量：{nickname}=昵称 {user_id}=QQ {group_id}=群号 {join_count}=第xx个入群
  welcomeText: `你是第{join_count}个加入({group_id})本群的人！`,
  // 退群通知文案，支持变量：{nickname}=昵称 {user_id}=QQ {group_id}=群号 {leave_type}=退群类型（主动退群/被踢出群）
  leaveText: `已退出({group_id})本群\n退群方式：{leave_type}`
};

let logger = null;

// ===================== 工具函数 =====================
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 获取QQ高清头像链接
function getAvatarUrl(qq) {
  return `https://q4.qlogo.cn/g?b=qq&nk=${qq}&s=${CONFIG.avatarSize}`;
}

// 【核心修复】通用获取群成员昵称函数，100%获取到名称，三重兜底
async function getMemberNickname(ctx, groupId, userId) {
  try {
    // 优先调用官方接口，获取最准确的群名片/昵称
    const memberInfo = await ctx.actions.call("get_group_member_info", {
      group_id: groupId,
      user_id: userId
    });
    // 优先取群名片，没有就取QQ昵称
    const nickname = memberInfo?.card || memberInfo?.nickname;
    if (nickname && nickname.trim()) {
      return nickname.trim();
    }
  } catch (e) {
    logger?.warn(`获取用户${userId}昵称失败，使用兜底方案`, e.message);
  }

  // 兜底1：从事件sender里取昵称
  try {
    const eventNickname = ctx.event?.sender?.nickname || ctx.event?.user_id?.nickname;
    if (eventNickname && eventNickname.trim()) {
      return eventNickname.trim();
    }
  } catch {}

  // 兜底2：直接用QQ号当名称，绝对不会为空
  return String(userId);
}

// 获取群成员总数（用于计算入群序号）
async function getGroupMemberCount(ctx, groupId) {
  try {
    const memberList = await ctx.actions.call("get_group_member_list", {
      group_id: groupId
    });
    return Array.isArray(memberList) ? memberList.length : null;
  } catch (e) {
    logger?.warn("获取群成员数量失败", e.message);
    return null;
  }
}

// 文案变量替换
function formatText(template, data) {
  return template.replace(/\{(\w+)\}/g, (_, key) => data[key] || "");
}

// ===================== NapCat插件核心生命周期 =====================
// 插件初始化
export async function plugin_init(ctx) {
  logger = ctx.logger || console;
  logger.info("【入群退群检测 稳定版】插件加载成功！");
  logger.info("【入群欢迎】状态：", CONFIG.enableWelcome ? "已开启" : "已关闭");
  logger.info("【退群通知】状态：", CONFIG.enableLeaveNotice ? "已开启" : "已关闭");
}

// 核心：事件监听（入群+退群全在这里捕获）
export async function plugin_onevent(ctx, event) {
  // 只处理通知类事件，其他直接跳过
  if (event.post_type !== EventType.NOTICE) return;

  const groupId = String(event.group_id);
  const userId = String(event.user_id);
  const operatorId = event.operator_id ? String(event.operator_id) : null;

  try {
    // ===================== 1. 处理新人入群事件 =====================
    if (CONFIG.enableWelcome && event.notice_type === EventType.GROUP_INCREASE) {
      // 1. 获取用户昵称（核心修复，100%拿到）
      const nickname = await getMemberNickname(ctx, groupId, userId);
      // 2. 获取入群序号
      const joinCount = await getGroupMemberCount(ctx, groupId);
      // 3. 获取头像
      const avatarUrl = getAvatarUrl(userId);

      // 控制台日志
      if (CONFIG.enableLog) {
        logger.info(`【新人入群】群号：${groupId}，QQ：${userId}，昵称：${nickname}，入群序号：${joinCount || "未知"}`);
      }

      // 拼接消息内容，严格按你要求的格式
      let msgContent = [];
      msgContent.push(`[CQ:image,file=${avatarUrl}]`);
      msgContent.push(`QQ：${userId}`);
      msgContent.push(`名称：${nickname}`);
      // 替换文案变量
      msgContent.push(formatText(CONFIG.welcomeText, {
        nickname: nickname,
        user_id: userId,
        group_id: groupId,
        join_count: joinCount || "未知"
      }));

      // 拼接@新人
      const finalMsg = CONFIG.atNewUser 
        ? `[CQ:at,qq=${userId}]\n${msgContent.join("\n")}`
        : msgContent.join("\n");

      // 延迟发送，避免风控
      await sleep(CONFIG.sendDelay);

      // 发送消息
      await ctx.actions.call("send_msg", {
        message_type: "group",
        group_id: groupId,
        message: finalMsg
      });

      logger.info(`【新人入群】群${groupId}已发送欢迎消息给${userId}`);
      return;
    }

    // ===================== 2. 处理退群事件 =====================
    if (CONFIG.enableLeaveNotice && event.notice_type === EventType.GROUP_DECREASE) {
      // 判断退群类型
      let leaveType = "主动退群";
      if (event.sub_type === "kick") {
        leaveType = operatorId ? `被管理员(${operatorId})踢出群` : "被踢出群";
      }

      // 获取用户昵称（退群也做了兜底，绝对不会为空）
      const nickname = await getMemberNickname(ctx, groupId, userId);
      // 获取头像
      const avatarUrl = getAvatarUrl(userId);

      // 控制台日志
      if (CONFIG.enableLog) {
        logger.info(`【成员退群】群号：${groupId}，QQ：${userId}，昵称：${nickname}，退群方式：${leaveType}`);
      }

      // 拼接退群消息，和入群格式统一
      let msgContent = [];
      msgContent.push(`[CQ:image,file=${avatarUrl}]`);
      msgContent.push(`QQ：${userId}`);
      msgContent.push(`名称：${nickname}`);
      // 替换文案变量
      msgContent.push(formatText(CONFIG.leaveText, {
        nickname: nickname,
        user_id: userId,
        group_id: groupId,
        leave_type: leaveType
      }));

      // 延迟发送
      await sleep(CONFIG.sendDelay);

      // 发送退群通知
      await ctx.actions.call("send_msg", {
        message_type: "group",
        group_id: groupId,
        message: msgContent.join("\n")
      });

      logger.info(`【成员退群】群${groupId}已发送退群通知`);
      return;
    }

  } catch (e) {
    logger?.error("【入群退群检测】处理异常", e);
  }
}
