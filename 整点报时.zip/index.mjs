import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let plugin_config_ui = [];

let currentConfig = {
  enableInstaller: true, // 全局总开关
  zdbs_groups: {},
  zdbs_friends: {}
};

let lastProcessedMinute = -1;

function saveConfig(ctx) {
  if (ctx.configPath) fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2));
}

// --- 获取北京时间 ---
function getBeijingTime() {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('zh-CN', {
        timeZone: 'Asia/Shanghai',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    });
    const parts = formatter.formatToParts(now);
    const hour = parseInt(parts.find(p => p.type === 'hour').value);
    const minute = parseInt(parts.find(p => p.type === 'minute').value);
    return { hour, minute };
}

// --- 获取一言 ---
async function getSaying() {
    try {
        const res = await fetch('https://uapis.cn/api/v1/saying', { signal: AbortSignal.timeout(5000) });
        const data = await res.json();
        return data.text || "光芒总会暗淡，但在暗淡背后，定将是更夺目的星光！";
    } catch (e) {
        return "愿你度过美好的一刻。";
    }
}

// --- 核心修复：定时报时任务（带退出机制） ---
function startCron(ctx) {
  setInterval(async () => {
    // 【关键修复点 1】：如果全局管理功能关闭，直接跳过本次循环，不执行任何报时操作
    if (currentConfig.enableInstaller === false) return;

    const { hour, minute } = getBeijingTime();
    
    // 确保每分钟只触发一次
    if (minute === lastProcessedMinute) return;
    lastProcessedMinute = minute;

    let type = "";
    if (minute === 0) type = "hourly"; 
    else if (minute === 30) type = "half";
    else return;

    // 获取一言并构造消息
    const saying = await getSaying();
    const timeStr = `${hour < 10 ? '0' + hour : hour}:${minute < 10 ? '0' + minute : minute}`;
    const msg = `🔔 TinRaln · 报时\n------------\n⏰ 北京时间：${timeStr}\n💬 一言：${saying}`;

    const targets = [
      { db: currentConfig.zdbs_groups, key: 'group_id' },
      { db: currentConfig.zdbs_friends, key: 'user_id' }
    ];

    for (const target of targets) {
      for (const [id, cfg] of Object.entries(target.db)) {
        // 【关键修复点 2】：即使全局开着，也要检查具体群/好友的开启状态
        if (cfg.enabled && ((type === "hourly" && cfg.hourly) || (type === "half" && cfg.half))) {
          await ctx.actions.call("send_msg", { [target.key]: id, message: msg }).catch(() => {});
        }
      }
    }
  }, 30000); // 30秒扫一次
}

// --- 指令监听 ---
export async function plugin_onmessage(ctx, event) {
  // 如果全局功能禁用，不响应任何指令
  if (currentConfig.enableInstaller === false) return;

  const isGroup = (event.message_type === "group");
  const targetId = String(isGroup ? event.group_id : event.user_id);
  const cfg = isGroup ? currentConfig.zdbs_groups[targetId] : currentConfig.zdbs_friends[targetId];

  // 白名单检查
  if (!cfg || !cfg.enabled) return;

  const rawMsg = event.message.filter(i => i.type === "text").map(i => i.data.text).join("").trim();

  if (rawMsg === "当前时间") {
    const { hour, minute } = getBeijingTime();
    const saying = await getSaying();
    const timeStr = `${hour < 10 ? '0' + hour : hour}:${minute < 10 ? '0' + minute : minute}`;
    const reply = `🕒 TinRaln · 时间查询\n------------\n⏰ 北京时间：${timeStr}\n💬 一言：${saying}`;
    await ctx.actions.call("send_msg", { ...event, message: reply });
  }
}

// --- 路由与 WebUI ---
function registerWebUi(ctx) {
  const base = ctx.router;
  const ROUTE = "/zdbs_api";
  if (base?.static) base.static(ROUTE + "/static", path.join(__dirname, "webui"));

  base.get(ROUTE + "/data", async (req, res) => {
    try {
      const liveGroups = await ctx.actions.call("get_group_list", {}) || [];
      const liveFriends = await ctx.actions.call("get_friend_list", {}) || [];
      liveGroups.forEach(g => {
        const id = String(g.group_id);
        if (!currentConfig.zdbs_groups[id]) currentConfig.zdbs_groups[id] = { id, name: g.group_name, enabled: false, hourly: true, half: false };
        else currentConfig.zdbs_groups[id].name = g.group_name;
      });
      liveFriends.forEach(f => {
        const id = String(f.user_id);
        if (!currentConfig.zdbs_friends[id]) currentConfig.zdbs_friends[id] = { id, name: f.nickname, enabled: false, hourly: true, half: false };
        else currentConfig.zdbs_friends[id].name = f.nickname;
      });
      saveConfig(ctx);
      res.json({ code: 0, config: currentConfig });
    } catch (e) { res.json({ code: -1 }); }
  });

  base.post(ROUTE + "/update", async (req, res) => {
    const { type, id, data } = req.body;
    const db = type === 'group' ? currentConfig.zdbs_groups : currentConfig.zdbs_friends;
    if (db[id]) { Object.assign(db[id], data); saveConfig(ctx); }
    res.json({ code: 0, config: currentConfig });
  });

  if (base?.page) {
    base.page({ path: "zdbs-controller", title: "整点报时控制", icon: "schedule", htmlFile: "webui/dashboard.html" });
  }
}

// --- 初始化面板逻辑 ---
function initConfigUI(ctx) {
  if (!ctx.NapCatConfig) return [];
  // 这里在宿主配置界面增加一个“开启管理功能”的开关，对应 currentConfig.enableInstaller
  return ctx.NapCatConfig.combine(
    ctx.NapCatConfig.boolean("enableInstaller", "开启报时插件", currentConfig.enableInstaller, "关闭后将停止所有定时报时任务和指令响应")
  );
}

export async function plugin_init(ctx) {
  if (ctx.configPath && fs.existsSync(ctx.configPath)) {
    try { currentConfig = Object.assign(currentConfig, JSON.parse(fs.readFileSync(ctx.configPath, "utf-8"))); } catch (e) { }
  }
  if (!currentConfig.zdbs_groups) currentConfig.zdbs_groups = {};
  if (!currentConfig.zdbs_friends) currentConfig.zdbs_friends = {};
  
  registerWebUi(ctx);
  startCron(ctx); // 循环启动
  plugin_config_ui = initConfigUI(ctx);
}

export async function plugin_get_config() { return currentConfig; }
export async function plugin_set_config(ctx, c) {
  currentConfig = Object.assign(currentConfig, c);
  if (ctx.configPath) fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2));
}
export { plugin_config_ui };
