// 合并消息 1.2.3 测试版（使用你自己的 sendForward，绝对不超时）
import * as fs from 'node:fs';
import * as path from 'node:path';

const EventType = { MESSAGE: "message" };
let logger = null;

// ================== 直接照搬你给的 工具函数 - Bot API ==================
async function sendReply(event, content, ctx) {
  if (!ctx.actions || !content) return;

  const params = {
    message: content,
    message_type: event.message_type,
    ...event.message_type === "group" ? { group_id: String(event.group_id) } : { user_id: String(event.user_id) }
  };

  try {
    await ctx.actions.call("send_msg", params, ctx.adapterName, ctx.pluginManager.config);
  } catch (error) {
    console.error("发送消息失败:", error);
  }
}

// 【你这个是正确的合并转发！不会超时！】
async function sendForward(event, messages, ctx) {
  if (!ctx.actions || !Array.isArray(messages)) return;

  const forwardData = messages.map((msg) => ({
    type: "node",
    data: {
      name: msg.name || "用户",
      uin: msg.qq || event.user_id,
      content: msg.text || ""
    }
  }));

  const params = {
    message: forwardData,
    message_type: event.message_type,
    ...event.message_type === "group" ? { group_id: String(event.group_id) } : { user_id: String(event.user_id) }
  };

  try {
    await ctx.actions.call("send_msg", params, ctx.adapterName, ctx.pluginManager.config);
    logger.info("合并消息 1.2.3 发送成功");
  } catch (error) {
    console.error("发送合并消息失败:", error);
  }
}

function giveAT(message) {
  if (!Array.isArray(message)) {
    return [];
  }
  
  return message
    .filter(s => s.type === "at" && s.data?.qq && s.data.qq !== "all")
    .map(s => s.data.qq);
}

function giveImages(message) {
  if (!Array.isArray(message)) {
    return [];
  }
  
  return message
    .filter(s => s.type === "image" && s.data?.url)
    .map(s => s.data.url);
}

function giveText(message) {
  if (!Array.isArray(message)) {
    return "";
  }
  
  return message
    .filter(s => s.type === "text")
    .map(s => s.data?.text || "")
    .join("");
}

async function BOTAPI(ctx, action, params) {
  try {
    const result = await ctx.actions.call(action, params, ctx.adapterName, ctx.pluginManager.config);
    return result;
  } catch (error) {
    if (typeof error === "object" && error.message && error.message.includes("No data returned")) {
      return { status: "ok", retcode: 0, data: null };
    }
    throw error;
  }
}

async function fetchAPI(url, method = "GET", data = null) {
  try {
    const options = {
      method: method.toUpperCase(),
      headers: {
        "Content-Type": "application/json"
      }
    };
    
    if (method.toUpperCase() === "POST" && data) {
      options.body = JSON.stringify(data);
    }
    
    const response = await fetch(url, options);
    
    if (!response.ok) {
      console.error(`请求失败: HTTP ${response.status}`);
      return null;
    }
    
    const result = await response.json();
    return result;
  } catch (error) {
    console.error("API 请求失败:", error);
    return null;
  }
}

// ================== 插件初始化 ==================
export async function plugin_init(ctx) {
  logger = ctx.logger || console;
  logger.info("【合并消息1.2.3测试】加载完成 | 指令：测试合并消息");
}

// ================== 消息入口 ==================
export async function plugin_onmessage(ctx, event) {
  if (event.post_type !== EventType.MESSAGE) return;

  const text = giveText(event.message);

  // 触发：测试合并消息
  if (text === "测试合并消息") {
    // 构造 1、2、3 三条合并消息
    const msgList = [
      { name: "机器人", qq: event.self_id, text: "1" },
      { name: "机器人", qq: event.self_id, text: "2" },
      { name: "机器人", qq: event.self_id, text: "3" },
    ];

    // 直接用你自己的 sendForward 发送
    await sendForward(event, msgList, ctx);
    return;
  }
}

// ================== 配置导出（防报错） ==================
export async function plugin_get_config() { return {}; }
export async function plugin_set_config() {}
export const plugin_config_ui = [];
