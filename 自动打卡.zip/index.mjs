import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let plugin_config_ui = [];

// --- dk 核心配置 ---
let currentConfig = {
  enableInstaller: true,
  targetTime: "07:00", 
  lastDkDate: "",      
  dk_groups: {}        
};

function saveConfig(ctx) {
  if (ctx.configPath) fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2));
}

// --- 获取北京时间 ---
function getBeijingInfo() {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('zh-CN', {
        timeZone: 'Asia/Shanghai',
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hour12: false
    });
    const parts = formatter.formatToParts(now);
    const getV = (t) => parts.find(p => p.type === t).value;
    return {
        date: `${getV('year')}-${getV('month')}-${getV('day')}`,
        time: `${getV('hour')}:${getV('minute')}`
    };
}

// --- 核心调度：准时自动打卡 ---
function startDkScheduler(ctx) {
  setInterval(async () => {
    if (!currentConfig.enableInstaller) return;

    const { date, time } = getBeijingInfo();

    // 到点且今天没打过，则触发
    if (time === currentConfig.targetTime && currentConfig.lastDkDate !== date) {
      currentConfig.lastDkDate = date;
      saveConfig(ctx);

      for (const [id, cfg] of Object.entries(currentConfig.dk_groups)) {
        if (cfg.enabled) {
          // 凌晨自动打卡，静默执行
          ctx.actions.call("send_group_sign", { group_id: id }).catch(() => {});
        }
      }
    }
  }, 40000); 
}

// --- 消息监听：打卡测试 ---
export async function plugin_onmessage(ctx, event) {
  if (!currentConfig.enableInstaller || event.message_type !== "group") return;

  const targetId = String(event.group_id);
  const cfg = currentConfig.dk_groups[targetId];

  // 只有控制台开启的群才响应
  if (!cfg || !cfg.enabled) return;

  const rawMsg = event.message.filter(i => i.type === "text").map(i => i.data.text).join("").trim();

  // 指令：打卡测试
  if (rawMsg === "打卡测试") {
    // 立即触发官方签到，不发任何文字回执，成功与否看官方卡片
    ctx.actions.call("send_group_sign", { group_id: event.group_id }).catch(() => {});
  }
}

// --- WebUI 注册 ---
function registerWebUi(ctx) {
  const base = ctx.router;
  const ROUTE = "/dk_api";
  if (base?.static) base.static(ROUTE + "/static", path.join(__dirname, "webui"));

  base.get(ROUTE + "/data", async (req, res) => {
    try {
      const liveGroups = await ctx.actions.call("get_group_list", {}) || [];
      liveGroups.forEach(g => {
        const id = String(g.group_id);
        if (!currentConfig.dk_groups[id]) {
          currentConfig.dk_groups[id] = { id, name: g.group_name, enabled: false };
        } else {
          currentConfig.dk_groups[id].name = g.group_name;
        }
      });
      saveConfig(ctx);
      res.json({ code: 0, config: currentConfig });
    } catch (e) { res.json({ code: -1 }); }
  });

  base.post(ROUTE + "/update", async (req, res) => {
    const { id, enabled } = req.body;
    if (currentConfig.dk_groups[id]) {
      currentConfig.dk_groups[id].enabled = enabled;
      saveConfig(ctx);
    }
    res.json({ code: 0, config: currentConfig });
  });

  if (base?.page) {
    base.page({ path: "dk-controller", title: "自动打卡控制", icon: "timer", htmlFile: "webui/dashboard.html" });
  }
}

// --- 配置面板 ---
function initConfigUI(ctx) {
  if (!ctx.NapCatConfig) return [];
  return ctx.NapCatConfig.combine(
    ctx.NapCatConfig.boolean("enableInstaller", "开启自动打卡任务", currentConfig.enableInstaller, "开启后每天准时执行官方签到"),
    ctx.NapCatConfig.text("targetTime", "每日打卡时间 (HH:mm)", currentConfig.targetTime, "建议 07:00")
  );
}

export async function plugin_init(ctx) {
  if (ctx.configPath && fs.existsSync(ctx.configPath)) {
    try { currentConfig = Object.assign(currentConfig, JSON.parse(fs.readFileSync(ctx.configPath, "utf-8"))); } catch (e) { }
  }
  if (!currentConfig.dk_groups) currentConfig.dk_groups = {};
  
  registerWebUi(ctx);
  startDkScheduler(ctx);
  plugin_config_ui = initConfigUI(ctx);
}

export async function plugin_get_config() { return currentConfig; }
export async function plugin_set_config(ctx, c) {
  currentConfig = Object.assign(currentConfig, c);
  saveConfig(ctx);
}
export { plugin_config_ui };
