// NapCat 智谱AI大模型 兼容修复完整版
import * as fs from 'node:fs';
import * as path from 'node:path';

const EventType = { MESSAGE: "message" };

// ===================== 全局状态 =====================
let logger = null;
let plugin_config_ui = [];

// ===================== 默认配置 =====================
let currentConfig = {
  zhipuApiKey: "",
  triggerPrefix: "智谱+内容",
  model: "glm-4-flash",
  temperature: 0.7,
  maxTokens: 2000,
  timeout: 30000,
  enableReply: true,
  enableGroupChat: true,
  enablePrivateChat: true,
  sendThinkingTip: true
};

const ZHIPU_API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions";

// ===================== 通用发送函数 =====================
async function sendReply(event, msg, ctx) {
  if (!msg || !msg.trim()) return { success: false };
  try {
    const sendParams = {
      message: msg,
      message_type: event.message_type,
      ...event.message_type === "group" ? { group_id: String(event.group_id) } : {},
      ...event.message_type === "private" ? { user_id: String(event.user_id) } : {}
    };
    await ctx.actions.call("send_msg", sendParams);
    return { success: true };
  } catch (e) {
    logger?.error("消息发送失败：", e.message);
    return { success: false, error: e.message };
  }
}

// ===================== 智谱AI API调用 =====================
async function callZhiPuAI(userContent) {
  if (!currentConfig.zhipuApiKey || currentConfig.zhipuApiKey.trim() === "") {
    return { success: false, msg: "请先配置智谱APIkey" };
  }
  if (!currentConfig.triggerPrefix || currentConfig.triggerPrefix.trim() === "") {
    return { success: false, msg: "请先配置触发指令前缀" };
  }

  try {
    const controller = new AbortController();
    const timeoutTimer = setTimeout(() => controller.abort(), currentConfig.timeout);

    const response = await fetch(ZHIPU_API_URL, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Authorization": `Bearer ${currentConfig.zhipuApiKey.trim()}`,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
      },
      body: JSON.stringify({
        model: currentConfig.model.trim(),
        messages: [{ role: "user", content: userContent }],
        temperature: currentConfig.temperature,
        max_tokens: currentConfig.maxTokens,
        stream: false
      })
    });

    clearTimeout(timeoutTimer);

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorMsg = errorData.error?.message || `接口异常，状态码：${response.status}`;
      logger?.error("智谱API调用失败：", errorMsg);
      return { success: false, msg: errorMsg };
    }

    const result = await response.json();
    const replyContent = result.choices?.[0]?.message?.content;

    if (!replyContent) {
      logger?.warn("智谱API返回内容为空", result);
      return { success: false, msg: "AI返回内容为空，请重试" };
    }

    return { success: true, content: replyContent };

  } catch (e) {
    if (e.name === "AbortError") {
      return { success: false, msg: "请求超时，AI响应时间过长，请重试" };
    }
    logger?.error("智谱API调用异常：", e);
    return { success: false, msg: `请求异常：${e.message}` };
  }
}

// ===================== 兼容版配置UI初始化 =====================
function initConfigUI(ctx) {
  // 无配置能力直接返回空
  if (!ctx.NapCatConfig || typeof ctx.NapCatConfig.combine !== "function") {
    logger?.warn("当前NapCat版本不支持可视化配置，已跳过UI注册");
    return [];
  }

  const configList = [];

  // 兼容判断html方法
  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(
      ctx.NapCatConfig.html(`
        <div style="padding: 12px; background: rgba(0,122,255,0.05); border-radius: 8px; margin-bottom: 10px;">
          <h3 style="margin: 0; color: #007aff;">🤖 智谱AI大模型 配置</h3>
          <p style="margin: 5px 0 0; color: #666; font-size: 14px;">修改配置后自动保存生效</p>
        </div>
      `)
    );
  }

  // 核心配置
  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(ctx.NapCatConfig.html(`<div style="margin: 15px 0 8px; font-weight: 600;">📌 核心配置</div>`));
  }

  // 兼容password方法，没有就用text
  if (typeof ctx.NapCatConfig.password === "function") {
    configList.push(
      ctx.NapCatConfig.password(
        "zhipuApiKey",
        "智谱APIkey",
        currentConfig.zhipuApiKey,
        "智谱开放平台APIkey，必填"
      )
    );
  } else if (typeof ctx.NapCatConfig.text === "function") {
    configList.push(
      ctx.NapCatConfig.text(
        "zhipuApiKey",
        "智谱APIkey",
        currentConfig.zhipuApiKey,
        "智谱开放平台APIkey，必填"
      )
    );
  }

  // 触发指令
  if (typeof ctx.NapCatConfig.text === "function") {
    configList.push(
      ctx.NapCatConfig.text(
        "triggerPrefix",
        "触发指令前缀",
        currentConfig.triggerPrefix,
        "触发格式：前缀+内容，比如填“智谱”，发送“智谱 你好”触发对话"
      )
    );
  }

  // 功能开关
  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(ctx.NapCatConfig.html(`<div style="margin: 20px 0 8px; font-weight: 600;">🔧 功能开关</div>`));
  }

  if (typeof ctx.NapCatConfig.boolean === "function") {
    configList.push(
      ctx.NapCatConfig.boolean("enableReply", "开启插件总开关", currentConfig.enableReply, "关闭后完全不响应消息"),
      ctx.NapCatConfig.boolean("enableGroupChat", "开启群聊响应", currentConfig.enableGroupChat, "开启后群聊可触发对话"),
      ctx.NapCatConfig.boolean("enablePrivateChat", "开启私聊响应", currentConfig.enablePrivateChat, "开启后私聊可触发对话"),
      ctx.NapCatConfig.boolean("sendThinkingTip", "发送思考中提示", currentConfig.sendThinkingTip, "开启后AI响应前发送提示")
    );
  }

  // 模型参数
  if (typeof ctx.NapCatConfig.html === "function") {
    configList.push(ctx.NapCatConfig.html(`<div style="margin: 20px 0 8px; font-weight: 600;">⚙️ 模型参数</div>`));
  }

  if (typeof ctx.NapCatConfig.text === "function") {
    configList.push(
      ctx.NapCatConfig.text(
        "model",
        "调用模型",
        currentConfig.model,
        "可选：glm-4-flash（免费）、glm-4、glm-4-plus等"
      )
    );
  }

  if (typeof ctx.NapCatConfig.number === "function") {
    configList.push(
      ctx.NapCatConfig.number("temperature", "温度值", currentConfig.temperature, 0, 1, 0.1, "0-1，越低越严谨，越高越发散"),
      ctx.NapCatConfig.number("maxTokens", "回复最大长度", currentConfig.maxTokens, 100, 4000, 100, "单条回复最大token数"),
      ctx.NapCatConfig.number("timeout", "请求超时时间", currentConfig.timeout, 10000, 120000, 5000, "单位：毫秒，默认30秒")
    );
  }

  // 组合配置UI
  try {
    return ctx.NapCatConfig.combine(...configList);
  } catch (e) {
    logger?.warn("配置UI组合失败，跳过可视化配置", e.message);
    return [];
  }
}

// ===================== 插件生命周期 =====================
export async function plugin_init(ctx) {
  try {
    logger = ctx.logger || { info: console.log, warn: console.warn, error: console.error };
    logger.info("【智谱AI兼容版】开始初始化...");

    // 加载本地配置
    try {
      if (ctx.configPath && fs.existsSync(ctx.configPath)) {
        const savedConfig = JSON.parse(fs.readFileSync(ctx.configPath, "utf-8"));
        currentConfig = Object.assign(currentConfig, savedConfig);
        logger.info("【智谱AI】本地配置加载成功");
      }
    } catch (configErr) {
      logger.warn("【智谱AI】本地配置读取失败，使用默认配置", configErr.message);
    }

    // 初始化配置UI（异常不影响核心功能）
    try {
      plugin_config_ui = initConfigUI(ctx);
    } catch (uiErr) {
      logger.warn("【智谱AI】配置UI注册失败，不影响核心功能", uiErr.message);
    }

    logger.info("【智谱AI兼容版】✅ 插件初始化成功！");
    logger.info(`【智谱AI】触发指令：${currentConfig.triggerPrefix}+内容`);
    logger.info(`【智谱AI】使用模型：${currentConfig.model}`);
  } catch (initErr) {
    logger.error("【智谱AI兼容版】❌ 初始化异常", initErr);
    throw initErr;
  }
}

// 消息处理
export async function plugin_onmessage(ctx, event) {
  if (currentConfig.enableReply === false) return;
  if (event.post_type !== EventType.MESSAGE) return;

  const isGroup = event.message_type === "group";
  if (isGroup && currentConfig.enableGroupChat === false) return;
  if (!isGroup && currentConfig.enablePrivateChat === false) return;

  const rawMsg = (event.raw_message || "").trim();
  const triggerPrefix = currentConfig.triggerPrefix?.trim() || "智谱";
  const userId = String(event.user_id);

  if (!rawMsg.startsWith(triggerPrefix)) return;

  try {
    const userQuestion = rawMsg.replace(new RegExp(`^${triggerPrefix}`), "").trim();

    if (!userQuestion) {
      await sendReply(event, `请输入你要问的内容\n格式示例：${triggerPrefix} 写一段早安问候语`, ctx);
      return;
    }

    logger.info(`【智谱AI】用户${userId}提问：${userQuestion}`);

    if (currentConfig.sendThinkingTip) {
      await sendReply(event, "正在思考中，请稍候...", ctx);
    }

    const aiResult = await callZhiPuAI(userQuestion);

    if (!aiResult.success) {
      await sendReply(event, `AI响应失败：${aiResult.msg}`, ctx);
      return;
    }

    await sendReply(event, aiResult.content, ctx);
    logger.info(`【智谱AI】用户${userId}的提问已回复完成`);

  } catch (e) {
    logger.error("【智谱AI】执行异常：", e);
    await sendReply(event, `插件执行异常：${e.message}`, ctx);
  }
}

// 配置相关生命周期
export async function plugin_get_config() {
  return currentConfig;
}

export async function plugin_set_config(ctx, newConfig) {
  try {
    currentConfig = Object.assign(currentConfig, newConfig);

    if (ctx.configPath) {
      const configDir = path.dirname(ctx.configPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }
      fs.writeFileSync(ctx.configPath, JSON.stringify(currentConfig, null, 2), "utf-8");
      logger.info("【智谱AI】配置已更新并保存");
      logger.info(`【智谱AI】当前触发指令：${currentConfig.triggerPrefix}+内容`);
    }
  } catch (e) {
    logger.error("【智谱AI】配置保存失败", e);
    throw e;
  }
}

export async function plugin_on_config_change(ctx, ui, key, value, newConfig) {
  logger.info(`【智谱AI】配置更新：${key} = ${value}`);
}

export { plugin_config_ui };

export async function plugin_config_controller(ctx, ui, initialConfig) {
  logger.info("【智谱AI】配置控制器初始化完成");
  return () => {
    logger.info("【智谱AI】配置控制器已清理");
  };
}
