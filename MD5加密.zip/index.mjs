import * as crypto from 'node:crypto';

// 事件类型定义
const EventType = {
  MESSAGE: "message"
};

// 1. 插件初始化函数 (必须导出，否则加载失败)
export async function plugin_init(ctx) {
  const logger = ctx.logger || console;
  logger.info("【听雨-MD5加密】插件初始化成功！");
}

// 2. 消息处理函数
export async function plugin_onmessage(ctx, event) {
  if (event.post_type !== EventType.MESSAGE) return;

  const rawMsg = giveText(event.message);

  // 指令匹配
  if (rawMsg.startsWith("MD5加密")) {
    const content = rawMsg.replace("MD5加密", "").trim();

    if (!content) {
      await sendReply(event, "⚠️ 请输入内容，如：MD5加密123", ctx);
      return;
    }

    try {
      const md5Hash = crypto.createHash('md5').update(content).digest('hex');
      const reply = `🔐 MD5加密成功\n原始内容：${content}\n结果(大写)：${md5Hash.toUpperCase()}\n结果(小写)：${md5Hash}`;
      await sendReply(event, reply, ctx);
    } catch (err) {
      ctx.logger?.error("MD5加密异常:", err);
    }
  }
}

// --- 辅助工具函数 ---
function giveText(message) {
  if (!Array.isArray(message)) return "";
  return message.filter(s => s.type === "text").map(s => s.data?.text || "").join("").trim();
}

async function sendReply(event, content, ctx) {
  if (!ctx.actions || !content) return;
  const params = {
    message: content,
    message_type: event.message_type,
    ...event.message_type === "group" ? { group_id: String(event.group_id) } : { user_id: String(event.user_id) }
  };
  await ctx.actions.call("send_msg", params, ctx.adapterName, ctx.pluginManager.config);
}
